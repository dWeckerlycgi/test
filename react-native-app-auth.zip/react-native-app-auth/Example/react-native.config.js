const path = require('path');

module.exports = {
  dependencies: {
    'react-native-app-auth': {
      root: path.join(__dirname, '..'),
    },
  },
};
