---
name: ⚠️ Bug/Issue report
about: Please provide as much detail as possible to help us with a bug or issue.
---

## Issue

<!-- Please describe your issue here --^ and provide as much detail as you can. -->

---

## Environment

* **Your Identity Provider**: `e.g. IdentityServer 4 / Okta / Azure`
* **Platform that you're experiencing the issue on**: `iOS / Android / both`
* **Are you using Expo?**
