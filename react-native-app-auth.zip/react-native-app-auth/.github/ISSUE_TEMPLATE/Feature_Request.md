---
name: 🎁 Feature request
about: Requesting new features
---

<!-- Please describe the desired feature, especially detailing the problem it should solve  -->
