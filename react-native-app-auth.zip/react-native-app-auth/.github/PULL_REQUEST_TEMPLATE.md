Fixes #... <!-- Link the issue that will be fixed by merging this PR, e.g. Fixes #1234 -->

## Description

<!-- Include a summary of the work -->

## Steps to verify

<!-- Describe steps to verify -->

<!-- Please ensure you have have updated the tests, readme, typescript definitions -->
