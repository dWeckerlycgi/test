
# React Native OIDC 

This project contains oidc login/logout flow for react native

## Requirements

- Node.js
- Xcode
- yarn
- Android Emulator
- iOS Simulator



## Packages used

 - "react-native": "0.71.4"
 - "react-native-app-auth": "^6.4.3"
 - "react-native-paper": "^5.4.1"
 - "@react-navigation/native": "^6.1.6"
- "@react-navigation/native-stack": "^6.9.12"


## Installation

Install with yarn

```bash
  git clone https://github.com/satish-centrifuge/mobile-app-oidc.git
  cd mobile-app-oidc
  yarn
```
  
## Run on device

To run on android emulator

```bash
  npx react-native run-android
```

To run on ios simulator

```bash
  npx react-native run-ios
```


## Customizations

To customize this project with your own OIDC  values

- navigate to src/context/AuthContext.tsx
- Modify line 21 - line 40 with your own values
- Run on device again.


## Running Tests

To run tests, run the following command

```bash
  yarn test
```
