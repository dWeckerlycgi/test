/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */

import React from 'react';
import {Provider} from 'react-native-paper';
import {SafeAreaProvider} from 'react-native-safe-area-context';
import AuthContextProvider from './src/context/AuthContext';

import Navigation from './src/navigation';

function App(): JSX.Element {
  return (
    <SafeAreaProvider>
      <Provider>
        <AuthContextProvider>
          <Navigation />
        </AuthContextProvider>
      </Provider>
    </SafeAreaProvider>
  );
}

export default App;
