import React from 'react';
import {StyleSheet, View} from 'react-native';
import {Button} from 'react-native-paper';
import {useAuth} from '../context/AuthContext';

export default function ProfileScreen() {
  const {logout} = useAuth();
  return (
    <View style={styles.container}>
      <Button onPress={logout} mode="contained">
        Logout
      </Button>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {flex: 1, justifyContent: 'center', paddingHorizontal: 24},
});
