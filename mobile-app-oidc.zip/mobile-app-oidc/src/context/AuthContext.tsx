import React, {PropsWithChildren, useState} from 'react';
import {authorize, prefetchConfiguration, revoke} from 'react-native-app-auth';
type AuthState = {
  accessToken: string;
  accessTokenExpirationDate?: string;
  refreshToken: string;
};
type AuthContextType = {
  loggedIn: boolean;
  authState: AuthState;
  login: () => void;
  logout: () => void;
};
const AuthContext = React.createContext<AuthContextType>({
  loggedIn: false,
  authState: {accessToken: '', accessTokenExpirationDate: '', refreshToken: ''},
  login: () => true,
  logout: () => true,
});

const iOSRedirectURL = 'org.reactjs.native.example:/oauthredirect';

const auth0 = {
  issuer: 'http://localhost:8080/realms/r1',
  clientId: 'testclient',
  clientSecret: 'EjSSSLOGBQPnTzABs3rWOAZBncYO93bO',
  clientAuthMethod: 'post',
  redirectUrl: iOSRedirectURL,
  additionalParameters: {},
  scopes: ['openid', 'profile', 'email'],

  // serviceConfiguration: {
  //   authorizationEndpoint: 'https://samples.auth0.com/authorize',
  //   tokenEndpoint: 'https://samples.auth0.com/oauth/token',
  //   revocationEndpoint: 'https://samples.auth0.com/oauth/revoke'
  // }
};
const defaultAuthState = {
  accessToken: '',
  accessTokenExpirationDate: '',
  refreshToken: '',
};
const AuthContextProvider: React.FC<PropsWithChildren> = ({children}) => {
  const [loggedIn, setLoggedIn] = useState(false);
  const [authState, setAuthState] = useState(defaultAuthState);
  React.useEffect(() => {
    prefetchConfiguration({
      warmAndPrefetchChrome: true,
      connectionTimeoutSeconds: 5,
      ...auth0,
    });
  }, []);
  const login = async () => {
    try {
      console.log('loggin clicked');
      const newAuthState = await authorize({
        ...auth0,
        connectionTimeoutSeconds: 5,
        //iosPrefersEphemeralSession: true,
      });
      console.log('auth stattee ', newAuthState);
      setAuthState(newAuthState);

      setLoggedIn(true);
    } catch (err) {
      console.log('error logging in..', err);
    }
  };

  const logout = async () => {
    try {
      await revoke(auth0, {
        tokenToRevoke: authState.accessToken,
        sendClientId: false,
      });

      setAuthState({
        accessToken: '',
        accessTokenExpirationDate: '',
        refreshToken: '',
      });

      setLoggedIn(false);
      // setUserData(null);
    } catch (err) {
      console.log('error logging out..', err);
    }
  };

  const value = {
    loggedIn,
    authState,
    login,
    logout,
  };
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export default AuthContextProvider;

export function useAuth() {
  return React.useContext(AuthContext);
}
